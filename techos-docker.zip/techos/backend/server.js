const express = require('express');
const Database = require('better-sqlite3');
const cors = require('cors');
const PDFDocument = require('pdfkit');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = process.env.DB_PATH || '/data/techos.db';

// Garante que o diretório de dados existe
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '../frontend/public')));

// ============================================================
// DATABASE SETUP
// ============================================================
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS clientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    telefone TEXT,
    email TEXT,
    cpf_cnpj TEXT,
    endereco TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tecnicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    especialidade TEXT,
    telefone TEXT,
    email TEXT,
    ativo INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS tipos_servico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    descricao TEXT,
    valor_base REAL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS ordens_servico (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    numero TEXT UNIQUE NOT NULL,
    cliente_id INTEGER REFERENCES clientes(id),
    tecnico_id INTEGER REFERENCES tecnicos(id),
    tipo_servico_id INTEGER REFERENCES tipos_servico(id),
    status TEXT DEFAULT 'Aberta' CHECK(status IN ('Aberta','Em Andamento','Concluída','Cancelada')),
    prioridade TEXT DEFAULT 'Média' CHECK(prioridade IN ('Baixa','Média','Alta')),
    equipamento TEXT,
    numero_serie TEXT,
    descricao TEXT,
    observacoes TEXT,
    laudo TEXT,
    valor_pecas REAL DEFAULT 0,
    valor_mao_obra REAL DEFAULT 0,
    prazo DATE,
    data_conclusao DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS historico_os (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    os_id INTEGER REFERENCES ordens_servico(id) ON DELETE CASCADE,
    acao TEXT NOT NULL,
    descricao TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TRIGGER IF NOT EXISTS update_os_timestamp
    AFTER UPDATE ON ordens_servico
    BEGIN
      UPDATE ordens_servico SET updated_at = CURRENT_TIMESTAMP WHERE id = NEW.id;
    END;
`);

// Seed data
const seedCount = db.prepare('SELECT COUNT(*) as c FROM clientes').get().c;
if (seedCount === 0) {
  db.exec(`
    INSERT INTO clientes (nome, telefone, email, cpf_cnpj) VALUES
      ('João Silva', '(11) 98765-4321', 'joao@email.com', '123.456.789-00'),
      ('Maria Fernanda', '(21) 91234-5678', 'maria@email.com', '987.654.321-00'),
      ('Tech Solutions Ltda', '(11) 3333-4444', 'ti@techsol.com.br', '12.345.678/0001-99'),
      ('Carlos Mendes', '(85) 99876-1234', 'carlos@gmail.com', '111.222.333-44'),
      ('Empresa ABC', '(31) 3123-4567', 'suporte@abc.com.br', '98.765.432/0001-10');

    INSERT INTO tecnicos (nome, especialidade, telefone) VALUES
      ('Rafael Oliveira', 'Hardware', '(11) 91111-2222'),
      ('Amanda Costa', 'Software / SO', '(11) 93333-4444'),
      ('Lucas Pereira', 'Redes', '(11) 95555-6666'),
      ('Fernanda Lima', 'Full Stack', '(11) 97777-8888');

    INSERT INTO tipos_servico (nome, valor_base) VALUES
      ('Formatação / Reinstalação OS', 150),
      ('Limpeza e Manutenção', 80),
      ('Troca de HD / SSD', 120),
      ('Reparo de Placa', 200),
      ('Instalação de Programas', 60),
      ('Configuração de Rede', 100),
      ('Backup de Dados', 80),
      ('Substituição de Tela', 180),
      ('Configuração de Email', 50),
      ('Outros', 0);

    INSERT INTO ordens_servico (numero, cliente_id, tecnico_id, tipo_servico_id, status, prioridade, equipamento, numero_serie, descricao, valor_pecas, valor_mao_obra, prazo)
    VALUES
      ('0001', 1, 1, 1, 'Em Andamento', 'Alta', 'Notebook Dell Inspiron', 'DL-20981', 'Computador travando constantemente, solicitou formatação completa', 0, 150, date('now', '+3 days')),
      ('0002', 2, 2, 3, 'Aberta', 'Média', 'MacBook Pro 2019', 'MAC-8821', 'HD com setores defeituosos, cliente quer upgrade para SSD 1TB', 450, 120, date('now', '+6 days')),
      ('0003', 3, 3, 6, 'Aberta', 'Alta', 'Servidor HP ProLiant', 'HP-00123', 'Configurar VPN corporativa e políticas de firewall', 0, 500, date('now', '+1 days')),
      ('0004', 4, 4, 2, 'Concluída', 'Baixa', 'Desktop Positivo', 'PS-4512', 'Limpeza geral e troca de pasta térmica', 15, 80, date('now', '-2 days')),
      ('0005', 5, 2, 7, 'Concluída', 'Média', 'Servidor NAS', 'NAS-777', 'Configurar rotina de backup automático', 0, 350, date('now', '-5 days'));

    INSERT INTO historico_os (os_id, acao, descricao) VALUES
      (1, 'Criação', 'OS criada'),
      (1, 'Status', 'Status alterado para Em Andamento'),
      (2, 'Criação', 'OS criada'),
      (3, 'Criação', 'OS criada'),
      (4, 'Criação', 'OS criada'),
      (4, 'Conclusão', 'OS concluída com sucesso'),
      (5, 'Criação', 'OS criada'),
      (5, 'Conclusão', 'OS concluída com sucesso');
  `);
}

// ============================================================
// HELPERS
// ============================================================
function nextOsNumber() {
  const row = db.prepare('SELECT numero FROM ordens_servico ORDER BY CAST(numero AS INTEGER) DESC LIMIT 1').get();
  return String((row ? parseInt(row.numero) : 0) + 1).padStart(4, '0');
}

const getOS = (id) => db.prepare(`
  SELECT os.*, 
    c.nome as cliente_nome, c.telefone as cliente_tel, c.email as cliente_email, c.cpf_cnpj,
    t.nome as tecnico_nome,
    ts.nome as tipo_nome
  FROM ordens_servico os
  LEFT JOIN clientes c ON os.cliente_id = c.id
  LEFT JOIN tecnicos t ON os.tecnico_id = t.id
  LEFT JOIN tipos_servico ts ON os.tipo_servico_id = ts.id
  WHERE os.id = ?
`).get(id);

// ============================================================
// ROUTES — CLIENTES
// ============================================================
app.get('/api/clientes', (req, res) => {
  const rows = db.prepare('SELECT * FROM clientes ORDER BY nome').all();
  res.json(rows);
});

app.post('/api/clientes', (req, res) => {
  const { nome, telefone, email, cpf_cnpj, endereco } = req.body;
  if (!nome) return res.status(400).json({ error: 'Nome obrigatório' });
  const r = db.prepare('INSERT INTO clientes (nome, telefone, email, cpf_cnpj, endereco) VALUES (?,?,?,?,?)').run(nome, telefone||'', email||'', cpf_cnpj||'', endereco||'');
  res.json(db.prepare('SELECT * FROM clientes WHERE id=?').get(r.lastInsertRowid));
});

app.put('/api/clientes/:id', (req, res) => {
  const { nome, telefone, email, cpf_cnpj, endereco } = req.body;
  db.prepare('UPDATE clientes SET nome=?,telefone=?,email=?,cpf_cnpj=?,endereco=? WHERE id=?').run(nome,telefone,email,cpf_cnpj,endereco,req.params.id);
  res.json(db.prepare('SELECT * FROM clientes WHERE id=?').get(req.params.id));
});

app.delete('/api/clientes/:id', (req, res) => {
  db.prepare('DELETE FROM clientes WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ============================================================
// ROUTES — TECNICOS
// ============================================================
app.get('/api/tecnicos', (req, res) => {
  res.json(db.prepare('SELECT * FROM tecnicos ORDER BY nome').all());
});

app.post('/api/tecnicos', (req, res) => {
  const { nome, especialidade, telefone, email } = req.body;
  if (!nome) return res.status(400).json({ error: 'Nome obrigatório' });
  const r = db.prepare('INSERT INTO tecnicos (nome, especialidade, telefone, email) VALUES (?,?,?,?)').run(nome, especialidade||'', telefone||'', email||'');
  res.json(db.prepare('SELECT * FROM tecnicos WHERE id=?').get(r.lastInsertRowid));
});

app.put('/api/tecnicos/:id', (req, res) => {
  const { nome, especialidade, telefone, email, ativo } = req.body;
  db.prepare('UPDATE tecnicos SET nome=?,especialidade=?,telefone=?,email=?,ativo=? WHERE id=?').run(nome,especialidade,telefone,email,ativo??1,req.params.id);
  res.json(db.prepare('SELECT * FROM tecnicos WHERE id=?').get(req.params.id));
});

app.delete('/api/tecnicos/:id', (req, res) => {
  db.prepare('DELETE FROM tecnicos WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ============================================================
// ROUTES — TIPOS SERVIÇO
// ============================================================
app.get('/api/tipos-servico', (req, res) => {
  res.json(db.prepare('SELECT * FROM tipos_servico ORDER BY nome').all());
});

app.post('/api/tipos-servico', (req, res) => {
  const { nome, descricao, valor_base } = req.body;
  const r = db.prepare('INSERT INTO tipos_servico (nome, descricao, valor_base) VALUES (?,?,?)').run(nome, descricao||'', valor_base||0);
  res.json(db.prepare('SELECT * FROM tipos_servico WHERE id=?').get(r.lastInsertRowid));
});

// ============================================================
// ROUTES — ORDENS DE SERVIÇO
// ============================================================
app.get('/api/os', (req, res) => {
  const { status, search, prioridade } = req.query;
  let sql = `
    SELECT os.*, 
      c.nome as cliente_nome,
      t.nome as tecnico_nome,
      ts.nome as tipo_nome,
      (os.valor_pecas + os.valor_mao_obra) as total
    FROM ordens_servico os
    LEFT JOIN clientes c ON os.cliente_id = c.id
    LEFT JOIN tecnicos t ON os.tecnico_id = t.id
    LEFT JOIN tipos_servico ts ON os.tipo_servico_id = ts.id
    WHERE 1=1
  `;
  const params = [];
  if (status && status !== 'all') { sql += ' AND os.status = ?'; params.push(status); }
  if (prioridade) { sql += ' AND os.prioridade = ?'; params.push(prioridade); }
  if (search) {
    sql += ' AND (c.nome LIKE ? OR os.numero LIKE ? OR ts.nome LIKE ? OR os.equipamento LIKE ?)';
    const s = `%${search}%`;
    params.push(s, s, s, s);
  }
  sql += ' ORDER BY os.created_at DESC';
  res.json(db.prepare(sql).all(...params));
});

app.get('/api/os/:id', (req, res) => {
  const os = getOS(req.params.id);
  if (!os) return res.status(404).json({ error: 'OS não encontrada' });
  const historico = db.prepare('SELECT * FROM historico_os WHERE os_id = ? ORDER BY created_at DESC').all(os.id);
  res.json({ ...os, historico });
});

app.post('/api/os', (req, res) => {
  const { cliente_id, tecnico_id, tipo_servico_id, status, prioridade, equipamento, numero_serie, descricao, observacoes, valor_pecas, valor_mao_obra, prazo } = req.body;
  if (!cliente_id || !descricao) return res.status(400).json({ error: 'Cliente e descrição obrigatórios' });
  const numero = nextOsNumber();
  const r = db.prepare(`
    INSERT INTO ordens_servico (numero, cliente_id, tecnico_id, tipo_servico_id, status, prioridade, equipamento, numero_serie, descricao, observacoes, valor_pecas, valor_mao_obra, prazo)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(numero, cliente_id, tecnico_id||null, tipo_servico_id||null, status||'Aberta', prioridade||'Média', equipamento||'', numero_serie||'', descricao, observacoes||'', valor_pecas||0, valor_mao_obra||0, prazo||null);
  db.prepare('INSERT INTO historico_os (os_id, acao, descricao) VALUES (?,?,?)').run(r.lastInsertRowid, 'Criação', 'OS criada');
  res.json(getOS(r.lastInsertRowid));
});

app.put('/api/os/:id', (req, res) => {
  const old = db.prepare('SELECT status FROM ordens_servico WHERE id=?').get(req.params.id);
  const { cliente_id, tecnico_id, tipo_servico_id, status, prioridade, equipamento, numero_serie, descricao, observacoes, laudo, valor_pecas, valor_mao_obra, prazo } = req.body;
  db.prepare(`
    UPDATE ordens_servico SET cliente_id=?,tecnico_id=?,tipo_servico_id=?,status=?,prioridade=?,
    equipamento=?,numero_serie=?,descricao=?,observacoes=?,laudo=?,valor_pecas=?,valor_mao_obra=?,prazo=?,
    data_conclusao=CASE WHEN ? = 'Concluída' THEN CURRENT_TIMESTAMP ELSE data_conclusao END
    WHERE id=?
  `).run(cliente_id,tecnico_id||null,tipo_servico_id||null,status,prioridade,equipamento||'',numero_serie||'',descricao,observacoes||'',laudo||'',valor_pecas||0,valor_mao_obra||0,prazo||null,status,req.params.id);
  if (old && old.status !== status) {
    db.prepare('INSERT INTO historico_os (os_id, acao, descricao) VALUES (?,?,?)').run(req.params.id, 'Status', `Status alterado de "${old.status}" para "${status}"`);
  }
  res.json(getOS(req.params.id));
});

app.delete('/api/os/:id', (req, res) => {
  db.prepare('DELETE FROM ordens_servico WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ============================================================
// ROUTE — DASHBOARD STATS
// ============================================================
app.get('/api/dashboard', (req, res) => {
  const stats = db.prepare(`
    SELECT
      COUNT(*) as total,
      SUM(CASE WHEN status='Aberta' THEN 1 ELSE 0 END) as abertas,
      SUM(CASE WHEN status='Em Andamento' THEN 1 ELSE 0 END) as andamento,
      SUM(CASE WHEN status='Concluída' THEN 1 ELSE 0 END) as concluidas,
      SUM(CASE WHEN status='Cancelada' THEN 1 ELSE 0 END) as canceladas,
      SUM(CASE WHEN status='Concluída' THEN (valor_pecas+valor_mao_obra) ELSE 0 END) as receita_total,
      SUM(CASE WHEN status IN ('Aberta','Em Andamento') THEN (valor_pecas+valor_mao_obra) ELSE 0 END) as receita_pendente
    FROM ordens_servico
  `).get();

  const porPrioridade = db.prepare(`
    SELECT prioridade, COUNT(*) as total FROM ordens_servico
    WHERE status IN ('Aberta','Em Andamento') GROUP BY prioridade
  `).all();

  const recentes = db.prepare(`
    SELECT os.numero, os.status, os.prioridade, os.created_at,
      c.nome as cliente_nome, ts.nome as tipo_nome, t.nome as tecnico_nome
    FROM ordens_servico os
    LEFT JOIN clientes c ON os.cliente_id = c.id
    LEFT JOIN tipos_servico ts ON os.tipo_servico_id = ts.id
    LEFT JOIN tecnicos t ON os.tecnico_id = t.id
    ORDER BY os.created_at DESC LIMIT 8
  `).all();

  const porTecnico = db.prepare(`
    SELECT t.nome, COUNT(*) as total,
      SUM(CASE WHEN os.status='Concluída' THEN 1 ELSE 0 END) as concluidas
    FROM ordens_servico os
    JOIN tecnicos t ON os.tecnico_id = t.id
    GROUP BY t.id ORDER BY total DESC LIMIT 5
  `).all();

  res.json({ stats, porPrioridade, recentes, porTecnico });
});

// ============================================================
// ROUTE — PDF DA OS
// ============================================================
app.get('/api/os/:id/pdf', (req, res) => {
  const os = getOS(req.params.id);
  if (!os) return res.status(404).json({ error: 'OS não encontrada' });

  const doc = new PDFDocument({ margin: 50, size: 'A4' });
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Disposition', `inline; filename=OS-${os.numero}.pdf`);
  doc.pipe(res);

  // Header
  doc.rect(0, 0, 612, 80).fill('#1a1f2e');
  doc.fill('#ffffff').fontSize(22).font('Helvetica-Bold').text('TechOS', 50, 22);
  doc.fontSize(10).font('Helvetica').fill('#8892a4').text('Sistema de Ordens de Serviço', 50, 48);
  doc.fill('#3b82f6').fontSize(14).font('Helvetica-Bold').text(`OS #${os.numero}`, 450, 28, { align: 'right', width: 110 });
  doc.fill('#8892a4').fontSize(9).font('Helvetica').text(new Date(os.created_at).toLocaleDateString('pt-BR'), 450, 50, { align: 'right', width: 110 });

  doc.moveDown(3);

  // Status badge colors
  const statusColor = { 'Aberta': '#3b82f6', 'Em Andamento': '#f59e0b', 'Concluída': '#10b981', 'Cancelada': '#ef4444' };
  const prioColor = { 'Alta': '#ef4444', 'Média': '#f59e0b', 'Baixa': '#10b981' };

  // Info boxes
  const drawBox = (x, y, w, h, title, lines) => {
    doc.rect(x, y, w, h).fillAndStroke('#f8fafc', '#e2e8f0');
    doc.fill('#64748b').fontSize(8).font('Helvetica-Bold').text(title, x+10, y+10);
    doc.fill('#1e293b').fontSize(10).font('Helvetica');
    lines.forEach((l, i) => {
      if (l) doc.text(l, x+10, y+24+(i*15), { width: w-20 });
    });
  };

  const y0 = 110;
  drawBox(50, y0, 250, 80, 'CLIENTE', [os.cliente_nome, os.cliente_tel||'', os.cliente_email||'', os.cpf_cnpj||'']);
  drawBox(315, y0, 247, 80, 'ORDEM DE SERVIÇO', [`Número: #${os.numero}`, `Data: ${new Date(os.created_at).toLocaleDateString('pt-BR')}`, `Prazo: ${os.prazo ? new Date(os.prazo+'T12:00').toLocaleDateString('pt-BR') : '—'}`]);

  const y1 = y0 + 95;
  drawBox(50, y1, 120, 60, 'STATUS', [os.status]);
  drawBox(185, y1, 120, 60, 'PRIORIDADE', [os.prioridade]);
  drawBox(320, y1, 242, 60, 'TÉCNICO', [os.tecnico_nome || 'Não atribuído']);

  const y2 = y1 + 75;
  drawBox(50, y2, 512, 50, 'EQUIPAMENTO', [`${os.equipamento || '—'}   |   S/N: ${os.numero_serie || '—'}`]);

  const y3 = y2 + 65;
  const descH = Math.max(70, Math.ceil(os.descricao.length / 85) * 14 + 40);
  drawBox(50, y3, 512, descH, 'DESCRIÇÃO DO PROBLEMA', [os.descricao]);

  if (os.observacoes) {
    const y4 = y3 + descH + 10;
    drawBox(50, y4, 512, 60, 'OBSERVAÇÕES', [os.observacoes]);
  }

  if (os.laudo) {
    const y5 = y3 + descH + (os.observacoes ? 80 : 10);
    const laudoH = Math.max(70, Math.ceil(os.laudo.length / 85) * 14 + 40);
    drawBox(50, y5, 512, laudoH, 'LAUDO TÉCNICO', [os.laudo]);
  }

  // Financeiro
  doc.moveDown(2);
  const yf = doc.y + 10;
  doc.rect(50, yf, 512, 100).fillAndStroke('#f0fdf4', '#bbf7d0');
  doc.fill('#166534').fontSize(10).font('Helvetica-Bold').text('RESUMO FINANCEIRO', 60, yf+12);
  doc.fill('#374151').font('Helvetica').fontSize(10);
  doc.text(`Valor das Peças:`, 60, yf+30);
  doc.text(`R$ ${(+os.valor_pecas||0).toFixed(2).replace('.', ',')}`, 200, yf+30);
  doc.text(`Mão de Obra:`, 60, yf+48);
  doc.text(`R$ ${(+os.valor_mao_obra||0).toFixed(2).replace('.', ',')}`, 200, yf+48);
  doc.rect(50, yf+65, 512, 1).fill('#bbf7d0');
  doc.fill('#166534').fontSize(13).font('Helvetica-Bold').text('TOTAL:', 60, yf+72);
  doc.text(`R$ ${((+os.valor_pecas||0)+(+os.valor_mao_obra||0)).toFixed(2).replace('.', ',')}`, 200, yf+72);

  // Assinaturas
  const yas = doc.page.height - 120;
  doc.moveTo(60, yas).lineTo(240, yas).stroke('#cbd5e1');
  doc.moveTo(370, yas).lineTo(550, yas).stroke('#cbd5e1');
  doc.fill('#64748b').fontSize(9).font('Helvetica').text('Assinatura do Cliente', 80, yas+5);
  doc.text('Assinatura do Técnico', 390, yas+5);

  // Footer
  doc.rect(0, doc.page.height-35, 612, 35).fill('#1a1f2e');
  doc.fill('#64748b').fontSize(8).text(`TechOS — Emitido em ${new Date().toLocaleString('pt-BR')}`, 50, doc.page.height-22);

  doc.end();
});

// ============================================================
// ROUTE — EXPORT CSV
// ============================================================
app.get('/api/os/export/csv', (req, res) => {
  const rows = db.prepare(`
    SELECT os.numero, os.created_at, c.nome as cliente, ts.nome as servico,
      t.nome as tecnico, os.status, os.prioridade, os.equipamento, os.prazo,
      os.valor_pecas, os.valor_mao_obra, (os.valor_pecas+os.valor_mao_obra) as total
    FROM ordens_servico os
    LEFT JOIN clientes c ON os.cliente_id = c.id
    LEFT JOIN tecnicos t ON os.tecnico_id = t.id
    LEFT JOIN tipos_servico ts ON os.tipo_servico_id = ts.id
    ORDER BY os.created_at DESC
  `).all();

  const headers = ['Nº OS','Data','Cliente','Serviço','Técnico','Status','Prioridade','Equipamento','Prazo','Valor Peças','Mão de Obra','Total'];
  const csv = [headers, ...rows.map(r => [
    r.numero, new Date(r.created_at).toLocaleDateString('pt-BR'), r.cliente, r.servico,
    r.tecnico||'', r.status, r.prioridade, r.equipamento||'', r.prazo||'',
    r.valor_pecas, r.valor_mao_obra, r.total
  ])].map(r => r.map(c => `"${c}"`).join(',')).join('\n');

  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', 'attachment; filename=ordens_servico.csv');
  res.send('\uFEFF' + csv);
});

// SPA fallback
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`🔧 TechOS rodando em http://0.0.0.0:${PORT}`);
});
